<?php $hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";

    $connect = mysqli_connect($hostname, $user, $password, $databaseName);
?>