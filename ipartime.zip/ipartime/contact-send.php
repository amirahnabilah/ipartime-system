<?php
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Bravo Multi purpose HTML5 Web Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">Welcome Jobseeker</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+001) 123-456-789</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexuser.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="job_index.php">Home</a></li> 
                        <li><a href="job_about.php">About Us</a></li>
						
						
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">JobSeeker<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            
							<li><a href="job_partime.php">Company</a></li>
                            
                        </ul>
                    </li> 
					
					<li><a href="job_about.php">Search</a></li>
					
						
                        <li><a href="job_contact.php">Contact Us</a></li>
						<li><a href="logout.php">Log Out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	<!-- end header -->
<?php
if(isset ($_POST['submit'])) {
	$msg = 'Name:' .$_POST ['name'] ."\n"
	.'Email:' .$_POST ['email']."\n"
	.'Comment' .$_POST ['comment'];
	mail ('example@example.com');
} else {
	header ('location: job_contact.php');
	exit(0)
	
}
?>