<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">WELCOME EMPLOYER</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+001) 32-206-490</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                  <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
					    <li><a href="indexemp.php">Home</a></li> 
                        <li><a href="company_about.php">About Us</a></li>
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Employer<b class="caret"></b></a>
                        <ul class="dropdown-menu">
							<li><a href="company_register.php">Register</a></li>
							<li><a href="company.php">Company</a></li>
							<li><a href="partime_job.php">Partime Job</a></li>
                        </ul>
                    </li> 
						<li class="active"><a href="company_contact.php">Contact Us</a></li>
						<li><a href="index.php">Log out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Contact Us</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	
	<div class="container">
		<div class="row"> 
							<div class="col-md-12">
								<div class="about-logo">
							</div>
						</div>
								

	<h1>Thank You</h1>
	<p>Thank you for contact our company. You should receive a replay shortly.</p>
