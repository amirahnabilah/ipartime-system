<?php 


if(isset($_GET['job_id']))
{
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";


//get id to delete
$id = $_GET['job_id'];

//connect to mysql
$connect = mysqli_connect($hostname, $user, $password, $databaseName);

//mysql delete query
$q = "DELETE FROM `jobseeker` WHERE `job_id` = $id ";
$result = mysqli_query($connect, $q);

if ($result)
{
    echo 'Data deleted';
    header('location:jobseeker_list.php');

}else {
    echo 'Data not inserted';
}
mysqli_close($connect);


?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Delete Jobseeker</h1>
        <div class="">
            
            <div align "center">
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">Jobseeker successfully deleted!</h4>
                        </div>
                        <div class="panel-footer">
                             <a class="btn btn-success" href="indexadm.php?page=jobseeker_list">OK</a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php } ?>