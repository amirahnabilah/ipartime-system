<?php include('server.php');

if(isset($_GET['msg'])){
    echo "<script>
    alert('Salah Password Atau user Atau takde 	!');
    //self.location = 'login_emp.php';
</script>";
}

 ?>
<!DOCTYPE html>
<html>
<head>

	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body style="background-image:url(img/pic5.jpg)">

	<div class="header">
		<h2>Login</h2>
	</div>
	
	<form method="post" action="login_process_emp.php">

		<?php include('errors.php'); ?>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username" >
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="login_user">Login</button>
		</div>
		<p>
			Not yet a member? <a href="register_emp.php">Sign up</a>
		</p>
			<p>
				<a href="index.php">Home</a>
		</p>
	</form>


</body>
</html>