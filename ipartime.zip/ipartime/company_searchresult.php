<?php 
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper" class="home-page">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
	  <p class="pull-left hidden-xs">WELCOME EMPLOYER</p>
      <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+001) 32-206-490</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexuser.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
					    <li><a href="indexemp.php">Home</a></li> 
                        <li><a href="company_about.php">About Us</a></li>
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Employer<b class="caret"></b></a>
                        <ul class="dropdown-menu">
							<li><a href="company_register.php">Register</a></li>
							<li><a href="company.php">Company</a></li>
							<li><a href="partime_job.php">Partime Job</a></li>
                        </ul>
                    </li> 
						<li class="active"><a href="company_contact.php">Contact Us</a></li>
						<li><a href="index.php">Log out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->

<html>
<head><title>Amazong Books Store</title></head>

<body style=background-image:url(bookiii.jpg)>

<center>

<?php
$db="obs";
$searchtype=$_POST['searchtype'];
$searchvalue=$_POST['searchvalue'];

mysql_connect("localhost","root","")or die("Could not connect to server.".mysql_error());
mysql_select_db("obs")or die("Could not connect to database".mysql_error());

$query="SELECT * FROM admin WHERE $searchtype LIKE '$searchvalue'";
$result=mysql_query($query);
$num_rows=mysql_num_rows($result);

if($num_rows < 1)
{
echo "<br><br><h1 align='center'><b><u><font color='deae5a'>Amazong Books Store</font></u></b></h1></center>";
echo "<h3 align='center'>No Record Found</h3>";
}
else
{
echo "<br><br><h1 align='center'><b><u><font color='eae5a'>Amazong Books Store</font></u></b></h1></center>";
echo "<h2 style='color:#795e4b;text-align:center'>Book Search</h2>";
echo "<h4 style='color:#795e4b;text-align:center'>Record Found</h4>";
echo "<h4 style='color:#000;text-align:center'>There are <u>$num_rows</u> records.</h4><p>";
echo "<table border='1' width='400' bgcolor='#fff' align='center'>";
echo "<tr>";
echo "<th>Number</th>";
echo "<th>Title</th>";
echo "<th>Author</th>";
echo "</tr>";

while($get_info = mysql_fetch_row($result))
{
echo "<tr>";

foreach ($get_info as $field)
{
echo "<td align='center'>$field</td>";
}
echo "</tr>";
}
echo "</table>";
}
?>
<br>
<br>
<form method="POST" action="obs_mainpage.php">
<input type="submit" value="HOME" align="center">
</form>

</center>

</body>
</html>