<?php
if(isset($_POST['submit'])) {
	$msg = 'Name: ' .$_POST['name'] ."\n"
	       .'Email: ' .$_POST['email'] ."\n"
		   .'Message: ' .$_POST['message'];
	mail('arbaienariff.aa@gmail.com', 'Sample mail', 'Sample Contact', "From: myranabila97@gmail.com" );
	header('location:company_contact_tq.php');
} else {
	header('location: company_contact.php');
	exit(0);
}
?>