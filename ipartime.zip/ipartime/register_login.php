<?php include('company_server.php') ?>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
	<div class="header">
		<h2>Employer Registration</h2>
	</div>
	
	<form method="post" action="register_login.php">

		<?php include('company_errors.php'); ?>

		<div class="input-group">
			<label>Username</label>
			<input type="text" name="login_usr" value="<?php echo $login_usr; ?>">
		</div>
		<div class="input-group">
			<label>Email</label>
			<input type="email" name="login_email" value="<?php echo $login_email; ?>">
		</div>
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="com_pass_1">
		</div>
		<div class="input-group">
			<label>Confirm password</label>
			<input type="password" name="com_pass_2">
		</div>
		<div class="input-group">
			<button type="submit" class="btn" name="reg_user">Register</button>
		</div>
		<p>
			Already a member? <a href="company_login.php">Sign in</a><br></br>
		</p>
		
	</form>
</body>
</html>