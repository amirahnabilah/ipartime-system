<?php 
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper" class="home-page">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">WELCOME EMPLOYER</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+001) 32-206-490</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexuser.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
					    <li><a href="indexemp.php">Home</a></li> 
                        <li><a href="company_about.php">About Us</a></li>
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Employer<b class="caret"></b></a>
                        <ul class="dropdown-menu">
							<li><a href="company_register.php">Register</a></li>
							<li><a href="company.php">Company</a></li>
							<li><a href="partime_job.php">Partime Job</a></li>
                        </ul>
                    </li> 
						<li class="active"><a href="company_contact.php">Contact Us</a></li>
						<li><a href="index.php">Log out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->

<html>
<head><title>Ipartime</title></head>

<body style=background-image:url(bookiii.jpg)>

<center>

<?php
$db="ipartime";
$searchtype=$_POST['searchtype'];
$searchvalue=$_POST['searchvalue'];

mysql_connect("localhost","root","")or die("Could not connect to server.".mysql_error());
mysql_select_db("ipartime")or die("Could not connect to database".mysql_error());

$query="SELECT * FROM employeer WHERE $searchtype LIKE '$searchvalue'";
$result=mysql_query($query);
$num_rows=mysql_num_rows($result);

if($num_rows < 1)
{

echo "<h3 align='center'>No Record Found</h3>";
}
else
{

echo "<h2 style='color:#795e4b;text-align:center'>Job Search</h2>";
echo "<h4 style='color:#795e4b;text-align:center'>Record Found</h4>";
echo "<h4 style='color:#000;text-align:center'>There are <u>$num_rows</u> records.</h4><p>";
echo "<table border='3' width='1450' bgcolor='#fff' align='center'>";
echo "<tr>";
echo "<tr bgcolor='LightGreen'>";
echo "<th>Number</th>";
echo "<th><b>Company Name</b></th>";
echo"<th><b>Job Offer</b></th>";
echo"<th><b>Start Date</b></th>";
echo"<th><b>Last Date</b></th>";
echo"<th><b>Email</b></th>";
echo"<th><b>Number Phone</b></th>";
echo"<th><b>Address</b></th>";
echo"<th><b>Company Size</b></th>";
echo"<th><b>Company Registration Number</b></th>";
echo"<th><b>Company Type</b></th>";
echo"<th><b>Employeer Need</b></td>";
echo "</tr>";


while($get_info = mysql_fetch_row($result))
{
echo "<tr>";

foreach ($get_info as $field)
{
echo "<td align='center'>$field</td>";
}
echo "</tr>";
}
echo "</table>";
}
?>
<br>
<br>
</center>


<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>IPartime company Inc</strong><br>
					<br>
					 Dungun,Terengganu</address>
					<p>
						<i class="icon-phone"></i> Tel : (+603) 9273 0822<br>
						<i class="icon-fax"></i> Fax : (+603) 0297 7371<br>
						<i class="icon-envelope-alt"></i> Email : ipartime@gmail.com
					</p>
				</div>
			</div>
				<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Accout Number</h5>
					<ul class="link-list">
						<i class="icon-fax"></i>Maybank2u - 162085687077 <br>
						<i class="icon-fax"></i>CimbClick - 7010054907 <br>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Other Partime Platforms</h5>
					<ul class="link-list">
						<li><a href="https://www.maukerja.my/">www.maukerja.my</a></li>
						<li><a href="https://www.indeed.co.za/">www.indeed.com</a></li>
						<li><a href="https://www.ricebowl.my/">www.indeed.com</a></li>
						<li><a href="https://www.internsheeps.com/">www.internsheeps.com</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Logo</h5>
					<ul class="link-list">
					  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>

					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Company IPartime Sdn Bhd | 2017 | Terms & Condition | Privacy & Policy </span><a target="_blank"></a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="https://en-gb.facebook.com/login/" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>  
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>








