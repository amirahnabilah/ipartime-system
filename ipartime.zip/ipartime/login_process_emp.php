<?php
session_start(); 

$hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";

//connect to mysql
$connect = mysqli_connect($hostname, $user, $password, $databaseName);

if(isset($_POST['login_user'])){
	
$username = $_POST['username'];
$pass = $_POST['password'];

$password = md5($pass);
//cho $password;

$sql = "select * from users where username='$username' and password ='$password'";
$result = mysqli_query($connect,$sql);
$data = mysqli_num_rows($result);

echo $data;
if($data > 0){
	while ($data = $result->fetch_array()) {
		$role = $data['role'];
	}

	$_SESSION['role'] = $role;
	echo 'USER ROLE :'.$role;

	if ($role == 'admin') {
		echo 'admin';
		header('location:indexadm.php');
	}
	if ($role== 'employeer') {
		echo 'employeer';
		header('location:indexemp.php');
	}
	if ($role=='jobseeker') {
		echo 'jobseeker';
		header ('location:job_index.php');
	}
	

}else{
	header('location:login.php?msg=fail');
}
}

echo $role;

?>
