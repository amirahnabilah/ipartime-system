<?php 

if(isset($_GET['employeer_id']))
{
    $hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";


//get id to delete
$id = $_GET['employeer_id'];

//connect to mysql
$connect = mysqli_connect($hostname, $user, $password, $databaseName);

//mysql delete query
$q = "DELETE FROM `employeer` WHERE `emp_id` = $id ";
$result = mysqli_query($connect, $q);

if ($result)
{
    echo 'Data deleted';
    header('location:employeer_list.php');

}else {
    echo 'Data not inserted';
}
mysqli_close($connect);


?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Delete Staff</h1>
        <div class="">
            
            <div align "center">
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">Employeer successfully deleted!</h4>
                        </div>
                        <div class="panel-footer">
                             <a class="btn btn-success" href="indexadm.php?page=employeer_list">OK</a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php } ?>