<?php
// open security session 
session_start();
//check userId for that particular user who executed the sql
if(!isset($_SESSION['role']) || empty($_SESSION['role'])){
	
	header('Location: index.php');
}


?>