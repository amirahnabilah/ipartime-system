<?php 
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">Welcome Jobseeker</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No.(+001) 123-456-789</p>
      </div>
    </div>
  </div>
</div>
<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexuser.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="job_index.php">Home</a></li> 
                        <li><a href="job_about.php">About Us</a></li>
						
						
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">JobSeeker<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            
							<li><a href="job_partime.php">Company</a></li>
                            
                        </ul>
                    </li> 
					
					<li><a href="job_search.php">Search</a></li>
					
						
                        <li><a href="job_contact.php">Contact Us</a></li>
						<li><a href="logout.php">Log Out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Jobseeker Data</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<section class="section-padding">
		<div class="container">
			<div class="row showcase-section">
				
				
			</div>
		</div>
	</section>
	


<?php

// php code to Insert data into mysql database from input text
if(isset($_POST['job_usr'])){

    $hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";
    
// connect to mysql database using mysqli

    $conn = new mysqli($hostname, $user, $password, $databaseName);
    
// Check connection
    if ($conn -> connect_error){
        die("Connection failed: " . $conn->connect_error);
    }


    $job_id = mysqli_real_escape_string($conn, $_POST['job_id']);
    $job_usr = mysqli_real_escape_string($conn, $_POST['job_usr']);
    $job_address = mysqli_real_escape_string($conn, $_POST['job_address']);
	$job_email = mysqli_real_escape_string($conn, $_POST['job_email']);
    //$job_phone = mysqli_real_escape_string($conn, $_POST['job_phone']);
	$job_phone = mysqli_query($conn, $_POST['job_phone']);
    $job_bank_name = mysqli_real_escape_string($conn, $_POST['job_bank_name']);
	$job_acc_num = mysqli_real_escape_string($conn, $_POST['job_acc_num']);
	$job_gender = mysqli_real_escape_string($conn, $_POST['job_gender']);

	$sql = "INSERT INTO jobseeker (`job_id`,`job_usr`,`job_address`,`job_email`,`job_phone`,`job_bank_name`,`job_acc_num`,`gender`) VALUES ('','".$job_usr."','".$job_address."','".$job_email."','".$job_phone."','".$job_bank_name."','".$job_acc_num."','".$job_gender."')";

    if($conn->query($sql) === TRUE){
        echo "Record Added Sucessfully";
    }
	else
	{
		echo "Error" . $sql . "<br/>" . $conn->error; 
	}
    $conn->close();

?>

<script>
    alert("Jobseeker successfully added!");
    self.location = "job_partime.php";
</script>


<?php } else { ?>

<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">Insert Data</h1>
		<div class="">
			
			<form method="post" enctype="multipart/form-data" name="form1" id="form1" 
			action="">
				<div align "center">
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">Jobseeker Information</h4>
							</div>
							<div class="panel-body">
							
								<div class="form-group">
									<label class="control-label">Username</label>
									<input type="text" id="job_usr" name="job_usr" class="form-control" required />
								</div>			
								<div class="form-group">
									<label class="control-label">Address</label>
									<input type="text" id="job_address" name="job_address" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Email</label>
									<input type="email" id="job_email" name="job_email" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Phone Number</label>
									<input type="text" id="job_phone" name="job_phone"  class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Bank Name</label>
									<input type="text" id="job_bank_name" name="job_bank_name" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Account Number</label>
									<input type="text" id="job_acc_num" name="job_acc_num" class="form-control" required />
								</div>
								
									<div class="form-group">
									<label class="control-label">Gender</label>
						            <input type="radio" name="job_gender" value="male" > Male
                                    <input type="radio" name="job_gender" value="female" > Female<br>
								</div>
								
								
							</div
							<div class="panel-footer">
								<button type="submit" name="submit" class="btn btn-success">Submit</button>
								<button type="reset" class="btn btn-danger">Reset</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->

<?php } ?>


