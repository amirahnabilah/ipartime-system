<?php 
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">WELCOME EMPLOYER</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No.(+001) 123-456-789</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
					    <li><a href="indexemp.php">Home</a></li> 
                        <li><a href="company_about.php">About Us</a></li>
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Employer<b class="caret"></b></a>
                        <ul class="dropdown-menu">
							<li><a href="company_register.php">Register</a></li>
						
                        </ul>
                    </li> 
						<li><a href="company_search.php">Search</a></li>
						<li><a href="company_contact.php">Contact Us</a></li>
						<li><a href="index.php">Log out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Company Registration</h2>
			</div>
		</div>
	</div>
		</div>
			</div>
		</div>
	</div>
	
<?php

// php code to Insert data into mysql database from input text
if(isset($_POST['emp_company'])){

    $hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";
    
// connect to mysql database using mysqli

    $conn = new mysqli($hostname, $user, $password, $databaseName);
    
// Check connection
    if ($conn -> connect_error){
        die("Connection failed: " . $conn->connect_error);
    }
	
    $emp_id = mysqli_real_escape_string($conn, $_POST['emp_id']);
	$emp_company = mysqli_real_escape_string($conn, $_POST['emp_company']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$emp_regnum = mysqli_real_escape_string($conn, $_POST['emp_regnum']);
	$emp_comsize = mysqli_real_escape_string($conn, $_POST['emp_comsize']);
	$emp_comtype = mysqli_real_escape_string($conn, $_POST['emp_comtype']);
	$joboffer = mysqli_real_escape_string($conn, $_POST['joboffer']);
	$emp_need = mysqli_real_escape_string($conn, $_POST['emp_need']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
	$start_date = mysqli_real_escape_string($conn, $_POST['start_date']);
    $last_date = mysqli_real_escape_string($conn, $_POST['last_date']);

	$sql = "INSERT INTO employeer(`emp_id`, `emp_company`, `phone`, `email`, `emp_regnum`, `emp_comsize`, `emp_comtype`, `joboffer`, `emp_need`, `address`, `start_date`, `last_date`) 
	VALUES ('','".$emp_company."','".$phone."','".$email."','".$emp_regnum."','".$emp_comsize."','".$emp_comtype."','".$joboffer."','".$emp_need."','".$address."','".$start_date."','".$last_date."')";
    if($conn->query($sql) === TRUE){
        echo "Record Added Sucessfully";
    }
	else
	{
		echo "Error" . $sql . "<br/>" . $conn->error; 
	}
    $conn->close();

?>

<script>
    alert("Employer successfully added!");
    self.location = "company_list.php";
</script>



<?php } else { ?>

<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">Insert Data Employeer</h1>
		<div class="">
			
			<form method="post" enctype="multipart/form-data" name="form1" id="form1" 
			action="">
				<div align "center">
					<div class="col-md-6">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">Employeer Information</h4>
							</div>
							<div class="panel-body">
							
								<div class="form-group">
									<label class="control-label">Name Company</label>
									<input type="text" id="emp_company" name="emp_company" class="form-control" required />
								</div>			
								<div class="form-group">
									<label class="control-label">Job Offer</label>
									<input type="text" id="joboffer" name="joboffer" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Email</label>
									<input type="email" id="email" name="email" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Start Date</label>
									<input type="date" id="start_date" name="start_date" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Last Date</label>
									<input type="date" id="last_date" name="last_date" class="form-control" required />
									
								</div>
								<div class="form-group">
									<label class="control-label">Phone number</label>
									<input type="text" id="phone" name="phone" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Address</label>
									<input type="text" id="address" name="address" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Company's staff</label>
									<input type="number" id="emp_comsize" name="emp_comsize" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Registration number</label>
									<input type="text" id="emp_regnum" name="emp_regnum" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Company type</label>
									<input type="text" id="emp_comtype" name="emp_comtype" class="form-control" required />
								</div>
								<div class="form-group">
									<label class="control-label">Staff need</label>
									<input type="number" id="emp_need" name="emp_need" class="form-control" required />
								</div>
							</div
							<div class="panel-footer">
								<button type="submit" name="submit" class="btn btn-success">Submit</button>
								<button type="reset" class="btn btn-danger">Reset</button>
							</div>
						</div>
					</div>
				</div>
			</form>
			
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->



	<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>IPartime company Inc</strong><br>
					<br>
					 Dungun,Terengganu</address>
					<p>
						<i class="icon-phone"></i> Tel : (+603) 9273 0822<br>
						<i class="icon-fax"></i> Fax : (+603) 0297 7371<br>
						<i class="icon-envelope-alt"></i> Email : ipartime@gmail.com
					</p>
				</div>
			</div>
				<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Accout Number</h5>
					<ul class="link-list">
						<i class="icon-fax"></i>Maybank2u - 162085687077 <br>
						<i class="icon-fax"></i>CimbClick - 7010054907 <br>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Other Partime Platforms</h5>
					<ul class="link-list">
						<li><a href="https://www.maukerja.my/">www.maukerja.my</a></li>
						<li><a href="https://www.indeed.co.za/">www.indeed.com</a></li>
						<li><a href="https://www.ricebowl.my/">www.indeed.com</a></li>
						<li><a href="https://www.internsheeps.com/">www.internsheeps.com</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Logo</h5>
					<ul class="link-list">
					  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>

					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Company IPartime Sdn Bhd | 2017 | Terms & Condition | Privacy & Policy </span><a target="_blank"></a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="https://en-gb.facebook.com/login/" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>  
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>
<?php } ?>