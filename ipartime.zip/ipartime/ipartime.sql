-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2017 at 11:58 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ipartime`
--

-- --------------------------------------------------------

--
-- Table structure for table `employeer`
--

CREATE TABLE `employeer` (
  `emp_id` int(11) NOT NULL,
  `emp_company` varchar(255) NOT NULL,
  `joboffer` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `emp_comsize` int(10) NOT NULL,
  `emp_regnum` varchar(255) NOT NULL,
  `emp_comtype` varchar(255) NOT NULL,
  `emp_need` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeer`
--

INSERT INTO `employeer` (`emp_id`, `emp_company`, `joboffer`, `start_date`, `last_date`, `email`, `phone`, `address`, `emp_comsize`, `emp_regnum`, `emp_comtype`, `emp_need`) VALUES
(8, 'nurin sdn bhd', 'accounting', '2017-08-23', '2017-09-23', 'admin@com.my', 132000, 'selangor', 0, '', '', 0),
(9, '', '', '2017-08-23', '2017-08-27', 'ain@gmail.com', 13200000, 'gambang', 0, '', '', 0),
(13, 'mami sdn bhd', 'maid', '2017-08-24', '2017-08-31', 'rose@mami.com.my', 133000, 'ampang', 0, '', '', 0),
(15, 'baien enterprise', 'accounting', '2017-08-23', '2017-08-31', 'baienenterprise@gmail.com', 197615426, 'no 12 jalan semarak 51200 kl', 200, 'ad56253', 'swasta', 2),
(18, 'lkja', 'mxx', '2017-09-19', '2017-09-20', 'sunshine@gmail.com', 5678, 'we', 2, 'sxdcw2', 'swasta', 3),
(19, '', '', '0000-00-00', '0000-00-00', '', 0, '', 0, '', '', 0),
(20, '', '', '0000-00-00', '0000-00-00', '', 0, '', 0, '', '', 0),
(22, '', '', '0000-00-00', '0000-00-00', '', 0, '', 0, '', '', 0),
(23, '', '', '0000-00-00', '0000-00-00', '', 0, '', 0, '', '', 0),
(25, 'chocolate sdn bhd', 'baker', '2017-09-19', '2017-09-30', 'chocolate@gmail.com', 132005240, 'dungun terengganu', 5, 'B11', 'swasta', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE `jobseeker` (
  `job_id` int(11) NOT NULL,
  `job_usr` varchar(255) NOT NULL,
  `job_address` varchar(255) NOT NULL,
  `job_email` varchar(255) NOT NULL,
  `job_phone` int(255) NOT NULL,
  `job_bank_name` varchar(255) NOT NULL,
  `job_acc_num` int(255) NOT NULL,
  `gender` text NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobseeker`
--

INSERT INTO `jobseeker` (`job_id`, `job_usr`, `job_address`, `job_email`, `job_phone`, `job_bank_name`, `job_acc_num`, `gender`, `status`) VALUES
(4, 'wany', 'kl', 'wany@yahoo.com', 1280000, '', 82313132, '', ''),
(5, 'a', 'b', 'c', 1, '', 2, '', ''),
(6, 'hafiz', 'selangor', 'hafiz@gmail.com', 1380000, '', 2147483647, '', ''),
(7, 'ayda', 'ampang', 'ayda@yahoo.com', 1270000, 'cimb', 2147483647, '', ''),
(9, 'gemuk', 'dungun', 'gemuk@yahoo.com', 1220000, 'CIMB', 2147483647, '', ''),
(10, 'amirah', 'damansara', 'myra', 0, '', 0, '', ''),
(13, 'mimi', 'johor', 'mimi@gmail.com', 1400000, 'CIMB', 234567890, 'female', ''),
(14, 'omotz', 'pasir gudang,johor', 'omotz@gmail.com', 182216491, 'Maybank', 61230520, 'female', ''),
(15, 'lola', 'narnia', 'lola@gmail.com', 1280000, 'public bank', 82092, 'female', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `role`) VALUES
(10, 'jobseeker', '827ccb0eea8a706c4c34a16891f84e7b', 'jobseeker@gmail.com', 'jobseeker'),
(11, 'company', '81dc9bdb52d04dc20036dbd8313ed055', 'company@gmail.com', 'employeer'),
(12, 'admin', '123456', 'admin@gmail.com', 'admin'),
(13, 'atiqah', '64ad3fb166ddb41a2ca24f1803b8b722', 'atiqah@gmail.com', 'employeer'),
(14, 'jobseeker', 'e10adc3949ba59abbe56e057f20f883e', 'jobseeker@gmail.com', 'jobseeker'),
(15, 'amirah', '64c855d557721daf9e5653c7c22fa092', 'amirah97@gmail.com', 'admin'),
(16, 'admin', 'a576393831dbed836eb84cb4108e101f', 'admin@gmail.com', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employeer`
--
ALTER TABLE `employeer`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `jobseeker`
--
ALTER TABLE `jobseeker`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employeer`
--
ALTER TABLE `employeer`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `jobseeker`
--
ALTER TABLE `jobseeker`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
