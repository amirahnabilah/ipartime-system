<?php 
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">WELCOME EMPLOYER</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+001) 32-206-490</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="indexemp.php">Home</a></li> 
                        <li class="active"><a href="company_about.php">About Us</a></li>
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Employer<b class="caret"></b></a>
                        <ul class="dropdown-menu">
							<li><a href="company_register.php">Register</a></li>
							
                        </ul>
                    </li> 
						<li><a href="company_search.php">Search</a></li>
						<li><a href="company_contact.php">Contact Us</a></li>
						<li><a href="index.php">Log out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">About Us</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
	<section class="section-padding">
		<div class="container">
			<div class="row showcase-section">
				<div class="col-md-6">
					<img src="img/9.png" alt="showcase image">
				</div>
				<div class="col-md-6">
					<div class="about-text">
						<h3>About</h3>
						<p> IPartime is a leader of one stop centre for part time provider in Malaysia. We are now a local based companiesm in Malaysia. </p>
						<h3>Vision</h3>
						<p> To developand maintain long lasting relationships with the clients and the jobseekers.</p>
						<h3>Mission</h3>
						<p> A bridge that connecting dream job with the potential jobseekers.</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="container">
					
					<div class="about">
				
						
						<div class="row">
							<div class="col-md-4">
								<!-- Heading and para -->
								<div class="block-heading-two">
									<h3><span>Why Choose Us?</span></h3>
								</div>
								<p>Registration is free for employer and jobseekers. <br/>
								<br/>Every application from the jobseekers will be treated private and confidential. We will not disclose the jobseeker's details to any third party.</p>
							</div>
							<div class="col-md-4">
								<div class="block-heading-two">
									<h3><span>Our Solution</span></h3>
								</div>		
								<!-- Accordion starts -->
								<div class="panel-group" id="accordion-alt3">
								 <!-- Panel. Use "panel-XXX" class for different colors. Replace "XXX" with color. -->
								  <div class="panel">	
									<!-- Panel heading -->
									 <div class="panel-heading">
										<h4 class="panel-title">
										  <a data-toggle="collapse" data-parent="#accordion-alt3" href="#collapseOne-alt3">
											<i class="fa fa-angle-right"></i> Terengganu
										  </a>
										</h4>
									 </div>
									 <div id="collapseOne-alt3" class="panel-collapse collapse">
										<!-- Panel body -->
										<div class="panel-body">
										<p> Kuala Terengganu </p>
										<p> Marang </p>
										<p> Kuala Dungun </p>
										<p> Kerteh </p>
										<p> Paka </p>
										<p> Kemaman </p>
										<p> Rantau Abang </p>
										<p> Che Lijah </p>
										</div>
									 </div>
								  </div>
								<!-- Accordion ends -->
				
					</div>
									
				</div>
	</section>
	
	<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>IPartime company Inc</strong><br>
					<br>
					 Dungun,Terengganu</address>
					<p>
						<i class="icon-phone"></i> Tel : (+603) 9273 0822<br>
						<i class="icon-fax"></i> Fax : (+603) 0297 7371<br>
						<i class="icon-envelope-alt"></i> Email : ipartime@gmail.com
					</p>
				</div>
			</div>
				<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Accout Number</h5>
					<ul class="link-list">
						<i class="icon-fax"></i>Maybank2u - 162085687077 <br>
						<i class="icon-fax"></i>CimbClick - 7010054907 <br>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Other Partime Platforms</h5>
					<ul class="link-list">
						<li><a href="https://www.maukerja.my/">www.maukerja.my</a></li>
						<li><a href="https://www.indeed.co.za/">www.indeed.com</a></li>
						<li><a href="https://www.ricebowl.my/">www.indeed.com</a></li>
						<li><a href="https://www.internsheeps.com/">www.internsheeps.com</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Logo</h5>
					<ul class="link-list">
					  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>

					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Company IPartime Sdn Bhd | 2017 | Terms & Condition | Privacy & Policy </span><a target="_blank"></a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="https://en-gb.facebook.com/login/" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>  
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>