<?php

// open security session 
session_start();

session_destroy();


?>
<script>
    alert("Are you sure you want to logout?");
    self.location = "index.php";
</script>