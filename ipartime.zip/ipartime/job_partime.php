<?php 
include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper" class="home-page">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">Welcome Jobseeker</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+601) 32206490</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexuser.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="job_index.php">Home</a></li> 
                        <li><a href="job_about.php">About Us</a></li>
                        
                        
                        <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">JobSeeker<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            
                            <li class="active"><a href="job_partime.php">Company</a></li>
                            
                        </ul>
                    </li> 
                    
                    <li><a href="job_search.php">Search</a></li>
                    
                        
                        <li><a href="job_contact.php">Contact Us</a></li>
                        <li><a href="logout.php">Log Out</a></li>
                    </ul>
                </div>
            </div>
        </div>
	<!-- end header -->
		
<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Job list</h2>
			</div>
		</div>
	</div>
	</section>
	<section id="content">
		<div class="container content">	
		
			
			
<?php

$hostname = "localhost";
    $user = "root";
    $password = "";
    $databaseName = "ipartime";  
//  $hostname = "ftp.byethost24.com";
   // $user = "b24_20714378";
   // $password = "123456789abc";
   // $databaseName = "ipartime";
    
// connect to mysql database using mysqli

    $connect = new mysqli($hostname, $user, $password, $databaseName);
    

 ///get the nama value from form
$q = "SELECT * from employeer"; //query to get the search result
$result = mysqli_query($connect, $q);
//execute the query $q
echo "<center>";
echo "<div class = 'table-responsive'>
<table class = 'table'>
<table class='table table-bordered'>

<tr bgcolor='orange'>
<td></td>
<td><b>Company Name</b></td>
<td><b>Phone Number</b></td>
<td><b>Email</b></td>
<td><b>Company Registration Number</b></td>
<td><b>Company Size Staff</b></td>
<td><b>Company Type</b></td>
<td><b>Job Offer</b></td>
<td><b>Employee Need</b></td>
<td><b>Company Address</b></td>
<td><b>Start Date</b></td>
<td><b>Last Date</b></td>
<td><b>Action</b></td>


</tr>";
while ($data = $result->fetch_array()){  //fetch the result from query into an array
echo "
<tr>

<td>".$data['emp_id']."</td>
<td>".$data['emp_company']."</td>
<td>".$data['phone']."</td>
<td>".$data['email']."</td>
<td>".$data['emp_regnum']."</td>
<td>".$data['emp_comsize']."</td>
<td>".$data['emp_comtype']."</td>
<td>".$data['joboffer']."</td>
<td>".$data['emp_need']."</td>
<td>".$data['address']."</td>
<td>".$data['start_date']."</td>
<td>".$data['last_date']."</td>
<div style='width:180px'>
<td><a class='btn btn-sm btn-success' href='job_add.php' >Apply</a>




</tr>";
			}
			echo "</table>";
			echo "</center>";

			?>

			<hr>
			
		
	</div>
	<!-- /.col-lg-12 -->
</div> 
<!-- /.row -->

<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>IPartime company Inc</strong><br>
					<br>
					 Dungun,Terengganu</address>
					<p>
						<i class="icon-phone"></i> Tel : (+603) 9273 0822<br>
						<i class="icon-fax"></i> Fax : (+603) 0297 7371<br>
						<i class="icon-envelope-alt"></i> Email : ipartime@gmailcom
					</p>
				</div>
			</div>
				<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Accout Number</h5>
					<ul class="link-list">
						<i class="icon-fax"></i>Mayback2u - 162085687077 <br>
						<i class="icon-fax"></i>CimbClick - 7010054907 <br>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Other Partime Platforms</h5>
					<ul class="link-list">
						<li><a href="https://www.maukerja.my/">www.maukerja.my</a></li>
						<li><a href="https://www.indeed.co.za/">www.indeed.com</a></li>
						<li><a href="https://www.ricebowl.my/">www.indeed.com</a></li>
						<li><a href="https://www.internsheeps.com/">www.internsheeps.com</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Logo</h5>
					<ul class="link-list">
					  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>

					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Company IPartime Sdn Bhd | 2017 | Terms & Condition | Privacy & Policy </span><a target="_blank"></a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="https://en-gb.facebook.com/login/" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>  
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>
