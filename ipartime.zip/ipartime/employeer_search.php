<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>IPartime</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://templateq.com" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
   
<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

</head>
<body>
<div id="wrapper" class="home-page">
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">Welcome Admin</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Tel No. (+601)32206490</p>
      </div>
    </div>
  </div>
</div>
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexadm.php"><img src="img/logo1.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="indexadm.php">Home</a></li> 
                         <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Manage Employeer<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="employeer_list.php">List Employeer</a></li>
                            <li><a href="employeer_add.php">Add Employeer</a></li>
							<li><a href="employeer_search.php">Search Employeer</a></li>
                        </ul>
                    </li> 
                            <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Manage Jobseeker<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="jobseeker_list.php">List Jobseeker</a></li>
                            <li><a href="jobseeker_add.php">Add Jobseeker</a></li>
								<li><a href="jobseeker_search.php">Search Jobseeker</a></li>
                        </ul>
                    </li> 
					
					  <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Advertisement<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="employeer_ads.php">Ads Employeer</a></li>
                            <li><a href="jobseeker_ads.php">Ads Jobseeker</a></li>
                        </ul>
                    </li> 
					
					
					      
                             <li><a  href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<!-- end header -->
	


<html>
<form method="POST" action="employeer_search_result.php">

<body style=background-image:url(bookiii.jpg)>


<center>
<form><table>
<h2 style="color:#795e4b;text-align:center">Job Offered </h2>

<select name="searchtype">
<option name="joboffer" value="joboffer">Job Offered</option>
<option name="emp_company" value="emp_company">Company</option>
</select>&nbsp;
<input type="text" name="searchvalue" rows="10"  size="20">
<br>
<br>
<input type="submit" value="Search">&nbsp;<input type="reset" value="Reset">
</form>
<br>
<br>
<br>
<br><br>
</form>

</center>

</body>
</html>




	<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Contact</h5>
					<address>
					<strong>IPartime company Inc</strong><br>
					<br>
					 Dungun,Terengganu</address>
					<p>
						<i class="icon-phone"></i> Tel : (+603) 9273 0822<br>
						<i class="icon-fax"></i> Fax : (+603) 0297 7371<br>
						<i class="icon-envelope-alt"></i> Email : ipartime7@gmail.com
					</p>
				</div>
			</div>
				<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Accout Number</h5>
					<ul class="link-list">
						<i class="icon-fax"></i>Maybank2u - 162085687077 <br>
						<i class="icon-fax"></i>CimbClick - 7010054907 <br>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Other Partime Platforms</h5>
					<ul class="link-list">
						<li><a href="https://www.maukerja.my/">www.maukerja.my</a></li>
						<li><a href="https://www.indeed.co.za/">www.indeed.com</a></li>
						<li><a href="https://www.ricebowl.my/">www.indeed.com</a></li>
						<li><a href="https://www.internsheeps.com/">www.internsheeps.com</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Our Logo</h5>
					<ul class="link-list">
					  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="indexemp.php"><img src="img/logo1.png" alt="logo"/></a>

					</ul>
				</div>
			</div>
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; Company IPartime Sdn Bhd | 2017 | Terms & Condition | Privacy & Policy </span><a target="_blank"></a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="https://en-gb.facebook.com/login/" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>  
<script src="js/jquery.flexslider.js"></script>
<script src="js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="js/modernizr.custom.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/animate.js"></script>
<script src="js/custom.js"></script>
<script src="js/owl-carousel/owl.carousel.js"></script>
</body>
</html>